<!DOCTYPE html>
<html lang="es">
    <!-- ATENCIÓN -->
    <!-- En el código encontrara el TAG Modificable con un número, un inicio y un fin de donde puede retocar con seguridad -->
    <head>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8">
        <?php $this->load->view('head') ?>
    </head>
    <!-- Modificable 1: Acceso de Identificación electronica -->
     <!-- ****** Notese que la ruta es la carpeta UPLOADS y la subcarpeta es el nombre del TEMA que se creara y el nombre de la imagen es el que usted elija ***** -->
    <body background="<?=base_url($template_path.'/background.jpg')?>">
    <!-- Fin Modificable 1 -->
    <ul class="saltar">
    <li><a href="#main" tabindex="1">Ir al contenido</a>
    </li>
</ul>
        <header>
            <div class="container">
                <div class="row">
                    <div class="span2">
                        <h1 id="logo"><a href="<?= site_url() ?>"><img src="<?= Cuenta::cuentaSegunDominio()!='localhost' ? Cuenta::cuentaSegunDominio()->logoADesplegar : base_url('assets/img/logo.png') ?>" alt="<?= Cuenta::cuentaSegunDominio()!='localhost' ? Cuenta::cuentaSegunDominio()->nombre_largo : 'Simple' ?>" /></a></h1>
                    </div>
                    <div class="span4">
                        <h1><?= Cuenta::cuentaSegunDominio()!='localhost' ? Cuenta::cuentaSegunDominio()->nombre_largo : '' ?></h1>
                        <p><?= Cuenta::cuentaSegunDominio()!='localhost' ? Cuenta::cuentaSegunDominio()->mensaje : '' ?></p>
                    </div>
                    <div class="offset3 span3">
                        <ul id="userMenu" class="nav nav-pills pull-right">
                            <?php if (!UsuarioSesion::usuario()->registrado): ?>
                                <li class="dropdown">
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Iniciar sesión<span class="caret"></span></a>
                                    <ul class="dropdown-menu pull-right">
                                        <li id="loginView">
                                            <div class="simple">
                                                <div class="wrapper">
                                            <form method="post" class="ajaxForm" action="<?= site_url('autenticacion/login_form') ?>">        
                                                <fieldset>
                                                    <div class="validacion"></div>
                                                    <input type="hidden" name="redirect" value="<?= current_url() ?>" />
                                                    <label for="usuario">Usuario o Correo electrónico</label>
                                                    <input name="usuario" id="usuario" type="text" class="input-xlarge">
                                                    <label for="password">Contraseña</label>
                                                    <input name="password" id="password" type="password" class="input-xlarge">
                                                    <p class="olvido"><a href="<?= site_url('autenticacion/olvido') ?>">¿Olvidaste tu contraseña?</a> - <a href="<?= site_url('autenticacion/registrar') ?>">Registrate aquí</a></p>
                                                    <button class="btn btn-primary pull-right" type="submit">Ingresar</button>
                                                </fieldset>
                                            </form>
                                            </div>
                                            </div>
                                            <!-- Modificable 2: Acceso de Identificación electronica -->
                                            <div class="claveunica">
                                                <div class="wrapper">
                                                <?php //if(!$claveunicaOnly):?><p>O utilice ClaveÚnica</p><?php //endif ?> 
                                                <a href="<?= site_url('autenticacion/login_openid?redirect=' . current_url()) ?>"><img src="<?= base_url() ?>assets/img/claveunica-medium.png" alt="OpenID"/></a>
                                                </div>
                                            </div>
                                            <!-- Fin Modificable 2 -->       
                                        </li>
                                    </ul>
                                </li>
                            <?php else: ?>
                                <li class="dropdown">
                                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">Bienvenido/a <?= UsuarioSesion::usuario()->displayName() ?><span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <?php if (!UsuarioSesion::usuario()->open_id): ?> 
                                            <li><a href="<?= site_url('cuentas/editar') ?>"><i class="icon-user"></i> Mi cuenta</a></li>
                                        <?php endif; ?>
                                        <?php if (!UsuarioSesion::usuario()->open_id): ?><li><a href="<?= site_url('cuentas/editar_password') ?>"><i class="icon-lock"></i> Cambiar contraseña</a></li><?php endif; ?>
                                        <li><a href="<?= site_url('autenticacion/logout') ?>"><i class="icon-off"></i> Cerrar sesión</a></li>
                                    </ul>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>

                </div>
            </div>
        </header>

        <div id="main">
            <div class="container">
                <div class="row">
                    <div class="span3">
                        <ul id="sideMenu" class="nav nav-list">    
                            <li class="iniciar <?= isset($sidebar) && $sidebar == 'disponibles' ? 'active' : '' ?>"><a href="<?= site_url('tramites/disponibles') ?>">Iniciar trámite</a></li>
                            <?php if (UsuarioSesion::usuario()->registrado): ?>
                                <?php
                                $npendientes=Doctrine::getTable('Etapa')->findPendientes(UsuarioSesion::usuario()->id, Cuenta::cuentaSegunDominio())->count();
                                $nsinasignar=Doctrine::getTable('Etapa')->findSinAsignar(UsuarioSesion::usuario()->id, Cuenta::cuentaSegunDominio())->count();
                                $nparticipados=Doctrine::getTable('Tramite')->findParticipadosALL(UsuarioSesion::usuario()->id, Cuenta::cuentaSegunDominio())->count();
                                ?>
                                <li class="<?= isset($sidebar) && $sidebar == 'inbox' ? 'active' : '' ?>"><a href="<?= site_url('etapas/inbox') ?>">Bandeja de Entrada (<?= $npendientes ?>)</a></li>
                                <?php if($nsinasignar): ?><li class="<?= isset($sidebar) && $sidebar == 'sinasignar' ? 'active' : '' ?>"><a href="<?= site_url('etapas/sinasignar') ?>">Sin asignar  (<?=$nsinasignar  ?>)</a></li><?php endif ?>
                                <li class="<?= isset($sidebar) && $sidebar == 'participados' ? 'active' : '' ?>"><a href="<?= site_url('tramites/participados') ?>">Historial de Trámites  (<?= $nparticipados ?>)</a></li>
                            <?php endif; ?>
                        </ul>
                        <!-- Modificable 3: Enlaces de Interes desplegados en barra lateral -->
                        <!-- ****** Notese que la ruta es la carpeta UPLOADS y la subcarpeta es el nombre del TEMA que se creara ***** -->
                        <h4>Enlaces de Interés</h4>
                        <p><a href="http://www.modernizacion.gob.cl/" target="_blank"><img src="<?=base_url($template_path.'/1.jpg')?>"/></a></p><br />
                        <p><a href="http://www.modernizacion.gob.cl/es/ejes-estrategicos/gobierno-abierto/software-publico/" target="_blank"><img src="<?=base_url($template_path.'/2.jpg')?>" /></a></p><br />
                        <p><a href="http://www.gob.cl/" target="_blank"><img src="<?=base_url($template_path.'/3.jpg')?>" /></a></p><br />
                        <!-- Fin Modificable 3 -->
                    </div>
                    <div class="offset1 span8">
                        <?php $this->load->view('messages') ?>
                        <?php $this->load->view($content) ?>
                    </div>
                </div>
            </div>
        </div>

        <footer>
            <div class="area1">
                <div class="container">
                    
                </div>
            </div>
            <div class="area2">
                <div class="container">
                    <div class="row">
                        <div class="span5">
                            <div class="col">
                                <div class="media">
                                    <div class="pull-left">
                                        <img class="media-object" src="<?= base_url() ?>assets/img/ico_cc.png" alt="CC" />
                                    </div>
                                    <div class="media-body">
                                        <!-- Modificable 4: Link de referencia de Institución-->
                                        <p class="modernizacion"><a href="http://www.ejemplo.gob.cl" target="_blank">Iniciativa de la Unidad de Modernización y Gobierno Digital</a><br/>
                                            <a class="ministerio" href="http://www.minsegpres.gob.cl" target="_blank">Ministerio Secretaría General de la Presidencia</a></p>
                                        <br />
                                        <!-- Fin Modificable 4 -->
                                        <!-- Modificable 5: Link de ayuda o de "acerca de SIMPLE" -->
                                        <p><a href="http://instituciones.chilesinpapeleo.cl/page/view/simple" target="_blank">Powered by SIMPLE</a></p>
                                        <!-- Fin Modificable 5 -->
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="span3">
                            <div class="col"></div>
                        </div>
                        <div class="span4">
                            &nbsp;
                        </div>
                    </div>
                    <!-- Modificable 6: Link de Institución o Gobierno-->
                    <a href="http://www.gob.cl" target="_blank"><img class="footerGob" src="<?= base_url() ?>assets/img/gobierno_chile.png" alt="Gobierno de Chile" /></a>
                    <!-- Fin Modificable 6 -->
                </div>
            </div>

        </footer>
    </body>
</html>
